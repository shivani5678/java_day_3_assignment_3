/*
- User defined package
- Why System.out.print?
- Why Scanner sc = new Scanner(System.in)
- Constructor

*/

/*
package ess;
class TestPackage {
    public static void main(String[] args) {
        System.out.print("Hello Coders");
    }
}
*/

/*
System.out.print() 
or 
System.out.println()

-print() & println() are nnn static members of PrintStream class (java.io package).
-To call print(), we need object of PrintStream class.
-"out" is an object of PrintStream, which is present as static member of System class(java.lang)
- so, to use out, we write System.out and consequently to use print()
  we write System.out.print().
*/

/*

Constructor: Method whose name is same as class name but no return
type (not even void).

class Test -> Test() { }


Demo ob = new Demo(); //creates object
Demo ob1 = ob;

- It implicitly invokes constructor and constructor creates object.
new Demo()  -> invokes constructor to create object
Demo ob     -> Reference Variable

Tasks of constructor:
- Creates object
- Initializes the object
*/

/*
class Test {
    int x;

    
    public static void main(String[] args) {
        Test ob = new Test();
        ob.x = 30;
        System.out.println("Data: " + ob.x);
    }
}

- JVM will automatically place a default constructor, if user do not
place any constructor.
*/

/*

Types of Constructor:
- Default
Test() {

}
- Parameterized

Test(int a) {

}
*/

/*
import java.util.Scanner;
class Cab {
    int fare;
    int d;

    public Cab() {
        fare = 30;
    }
    //parameterized constructor
    public Cab(int fare) {
        this.fare = fare;   //"this" gives reference of current object being used
        //ob.fare - fare
    }

    //copy constructor 
    public Cab(Cab ob1) {         //ob1 = ob
        fare = ob1.fare;   //ob2.fare = ob.fare
    }
}

class RideCab {
    public static void main(String[] args) {
        int cd; //distance of cab from user
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the cab distance from user: ");
        cd = sc.nextInt();

        if(cd > 5) {
            Cab ob = new Cab(30 + (cd - 5) * 10); //invokes param constructor
            System.out.print("Enter the distance travelled: ");
            ob.d = sc.nextInt();

            ob.fare += 10 * ob.d;

            System.out.println("Total fare: Rs " + ob.fare);

            
        }
        else {
            Cab ob = new Cab();
            System.out.print("Enter the distance travelled: ");
            ob.d = sc.nextInt();

            ob.fare += 10 * ob.d;

            System.out.println("Total fare: Rs " + ob.fare);

            Cab ob2 = new Cab(ob);
            System.out.println("Data ob2: " + ob2.fare);
        }

    }
}
*/

class Demo {
    private int x;

    //setter
    public void setX(int val) {
        x = val;
    }

    //getter
    public int getX() {
        return x;
    }
}

class DriveDemo {
    public static void main(String[] args) {
        Demo ob = new Demo();
        ob.setX(30);
        System.out.println("Data: " + ob.getX());
    }
}